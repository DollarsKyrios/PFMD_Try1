package com.example.marketgarden;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FinalPage extends AppCompatActivity {
    private Button end;
    private Button back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_page);

        Intent intent = getIntent();
        String name = intent.getStringExtra(MiddlePage.EXTRA_TEXT);
        String address = intent.getStringExtra(MiddlePage.EXTRA_TEXT2);

        TextView textView1 =  findViewById(R.id.name);
        TextView textView2 =  findViewById(R.id.address);

        textView1.setText(name);
        textView2.setText(address);


        end = findViewById(R.id.btnnext_page);
        end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFinalPage();
            }
        });

        back = findViewById(R.id.btnback_page);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMiddlePage();
            }
        });



    }
    public void openFinalPage(){
        Intent intent = new Intent(this, FinalPage.class);
        startActivity(intent);
    }

    public void openMiddlePage(){
        Intent intent = new Intent(this, MiddlePage.class);
        startActivity(intent);

    }
}
