package com.example.marketgarden;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


public class MiddlePage extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private Button btn;
    private Button bnt;
    public static final String EXTRA_TEXT = "com.example.marketgarden.EXTRA_TEXT";
    public static final String EXTRA_TEXT2 = "com.example.marketgarden.EXTRA_TEXT2";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_middle);

        Spinner spinner1 = findViewById(R.id.fruit_veg);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.fruit_veg, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter1);
        spinner1.setOnItemSelectedListener(this);

        Spinner spinner2 = findViewById(R.id.flowers);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.flowers, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(this);



        bnt = findViewById(R.id.btnback_page);
        bnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFirstPage();
            }
        });


        btn = findViewById(R.id.btnnext_page);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFinalPage();
            }
        });





    }


    // button to go back to first page
    public void openFirstPage(){
        Intent intent = new Intent(this, FirstPage.class);
        startActivity(intent);

    }

    //button function to go to final page
    public void openFinalPage(){
        //EditText editText1 = findViewById(R.id.name);
       // String name = editText1.getText().toString();

       // EditText editText2 = findViewById(R.id.address);
       // String address = editText2.getText().toString();


        Intent intent = new Intent(this, FinalPage.class);
       // intent.putExtra(EXTRA_TEXT, name);
        //intent.putExtra(EXTRA_TEXT2, address);
        startActivity(intent);
    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}






